// app/(tabs)/clinic.tsx
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Image,
  Linking,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { WebView } from "react-native-webview";
import { apiUrl } from "../../src/api/base";

type Topic = {
  id: number;
  name: string;
  slug: string;
  description?: string | null;
  featured_image_url?: string | null;
};

type Path = {
  id: number;
  name: string;
  slug: string;
  description?: string | null;
  intended_level?: string | null;
  est_total_minutes?: number | null;
  featured_image_url?: string | null;
  step_count?: number | null;
};

type Item = {
  id: number;
  title: string;
  slug: string;
  item_type?: string | null;
  skill_level?: string | null;
  est_minutes?: number | null;
  youtube_url?: string | null;
  featured_image_url?: string | null;
  excerpt?: string | null;
  content_html?: string | null;
};

type PathStep = {
  step_no: number;
  step_title: string;
  note?: string | null;
  item: Item;
};

type ViewState =
  | { name: "home" }
  | { name: "topics" }
  | { name: "topic"; slug: string; title?: string }
  | { name: "paths" }
  | { name: "path"; slug: string; title?: string }
  | { name: "item"; slug: string; title?: string }
  | { name: "filters"; slug: string; title?: string };

const TYPE_LABEL: Record<string, string> = {
  guide: "Guide",
  lesson: "Lesson",
  drill: "Drill",
  troubleshoot: "Troubleshoot",
};
const LEVEL_LABEL: Record<string, string> = {
  beginner: "Beginner",
  intermediate: "Intermediate",
  advanced: "Advanced",
  all: "All levels",
};

function compact(s?: string | null) {
  const t = (s ?? "").trim();
  return t.length ? t : null;
}

function pillText(it: { item_type?: string | null; skill_level?: string | null; est_minutes?: number | null }) {
  const parts: string[] = [];
  const t = compact(it.item_type)?.toLowerCase();
  const l = compact(it.skill_level)?.toLowerCase();
  if (t && TYPE_LABEL[t]) parts.push(TYPE_LABEL[t]);
  if (l && LEVEL_LABEL[l]) parts.push(LEVEL_LABEL[l]);
  if (typeof it.est_minutes === "number") parts.push(`${it.est_minutes} min`);
  return parts.join(" • ");
}

async function fetchJson<T>(path: string, signal?: AbortSignal): Promise<T> {
  const res = await fetch(apiUrl(path), { signal });
  return (await res.json()) as T;
}

function SmallThumb({
  title,
  subtitle,
  imageUrl,
  onPress,
}: {
  title: string;
  subtitle?: string | null;
  imageUrl?: string | null;
  onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.thumb, pressed && { opacity: 0.9 }]}>
      <View style={styles.thumbImgWrap}>
        {imageUrl ? <Image source={{ uri: imageUrl }} style={styles.thumbImg} /> : <View style={styles.thumbImgFallback} />}
      </View>
      <View style={styles.thumbBody}>
        <Text style={styles.thumbTitle} numberOfLines={2}>
          {title}
        </Text>
        {subtitle ? (
          <Text style={styles.thumbSub} numberOfLines={2}>
            {subtitle}
          </Text>
        ) : null}
      </View>
    </Pressable>
  );
}

function Row({
  title,
  subtitle,
  meta,
  imageUrl,
  onPress,
}: {
  title: string;
  subtitle?: string | null;
  meta?: string | null;
  imageUrl?: string | null;
  onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}>
      <View style={styles.rowImgWrap}>
        {imageUrl ? <Image source={{ uri: imageUrl }} style={styles.rowImg} /> : <View style={styles.rowImgFallback} />}
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowTitle} numberOfLines={2}>
          {title}
        </Text>
        {subtitle ? (
          <Text style={styles.rowSub} numberOfLines={2}>
            {subtitle}
          </Text>
        ) : null}
        {meta ? (
          <Text style={styles.rowMeta} numberOfLines={1}>
            {meta}
          </Text>
        ) : null}
      </View>
      <Ionicons name="chevron-forward" size={18} color={stylesVars.textDim} style={{ opacity: 0.9 }} />
    </Pressable>
  );
}

const stylesVars = {
  bg: "#0b0f1a",
  card: "rgba(255,255,255,0.06)",
  cardBorder: "rgba(255,255,255,0.09)",
  text: "rgba(255,255,255,0.92)",
  textDim: "rgba(255,255,255,0.72)",
  textFaint: "rgba(255,255,255,0.58)",
  accent: "#c7ff2e",
  accentInk: "#0b0f1a",
};

export default function ClinicTab() {
  const insets = useSafeAreaInsets();

  const [stack, setStack] = useState<ViewState[]>([{ name: "home" }]);
  const view = stack[stack.length - 1];

  const push = useCallback((v: ViewState) => setStack((s) => [...s, v]), []);
  const pop = useCallback(() => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)), []);
  const goHome = useCallback(() => setStack([{ name: "home" }]), []);

  const [topics, setTopics] = useState<Topic[] | null>(null);
  const [paths, setPaths] = useState<Path[] | null>(null);
  const [topicItems, setTopicItems] = useState<Record<string, Item[]>>({});
  const [pathSteps, setPathSteps] = useState<Record<string, PathStep[]>>({});
  const [itemDetail, setItemDetail] = useState<Record<string, Item>>({});

  // Topic filters
  const [q, setQ] = useState("");
  const [type, setType] = useState<string>("");
  const [level, setLevel] = useState<string>("");

  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const abortRef = useRef<AbortController | null>(null);

  // Used when rendering a Clinic lesson as an in-app WebView (SEO-canonical website page).
  const webViewRef = useRef<WebView>(null);
  const [webViewHeight, setWebViewHeight] = useState(600);

  const start = useCallback(async <T,>(fn: (signal: AbortSignal) => Promise<T>) => {
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;
    setLoading(true);
    try {
      return await fn(ac.signal);
    } finally {
      if (abortRef.current === ac) abortRef.current = null;
      setLoading(false);
    }
  }, []);

  const loadTopics = useCallback(async () => {
    const data = await start<{ ok: boolean; topics: Topic[]; error?: string }>((signal) =>
      fetchJson(`/api/v1/clinic/topics.php`, signal)
    );
    if (!data.ok) throw new Error(data.error || "Failed to load topics");
    setTopics(data.topics ?? []);
  }, [start]);

  const loadPaths = useCallback(async () => {
    const data = await start<{ ok: boolean; paths: Path[]; error?: string }>((signal) =>
      fetchJson(`/api/v1/clinic/paths.php`, signal)
    );
    if (!data.ok) throw new Error(data.error || "Failed to load paths");
    setPaths(data.paths ?? []);
  }, [start]);

  const loadTopic = useCallback(
    async (slug: string) => {
      const params = new URLSearchParams();
      if (q.trim()) params.set("q", q.trim());
      if (type) params.set("type", type);
      if (level) params.set("level", level);
      const qs = params.toString();

      const data = await start<{ ok: boolean; topic: Topic; items: Item[]; error?: string }>((signal) =>
        fetchJson(`/api/v1/clinic/topic.php?slug=${encodeURIComponent(slug)}${qs ? `&${qs}` : ""}`, signal)
      );

      if (!data.ok) throw new Error(data.error || "Failed to load topic");
      setTopicItems((m) => ({ ...m, [slug]: data.items ?? [] }));
      return data.topic;
    },
    [start, q, type, level]
  );

  const loadPath = useCallback(
    async (slug: string) => {
      const data = await start<{ ok: boolean; path: Path; steps: PathStep[]; error?: string }>((signal) =>
        fetchJson(`/api/v1/clinic/path.php?slug=${encodeURIComponent(slug)}`, signal)
      );

      if (!data.ok) throw new Error(data.error || "Failed to load path");
      setPathSteps((m) => ({ ...m, [slug]: data.steps ?? [] }));
      return data.path;
    },
    [start]
  );

  const loadItem = useCallback(
    async (slug: string) => {
      const data = await start<{ ok: boolean; item: Item; error?: string }>((signal) =>
        fetchJson(`/api/v1/clinic/item.php?slug=${encodeURIComponent(slug)}`, signal)
      );
      if (!data.ok) throw new Error(data.error || "Failed to load item");
      setItemDetail((m) => ({ ...m, [slug]: data.item }));
      return data.item;
    },
    [start]
  );

  useEffect(() => {
    (async () => {
      try {
        if (!topics) await loadTopics();
        if (!paths) await loadPaths();
      } catch {
        // allow retry UI
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Auto-load data when navigating deeper so users don't have to tap "Load"
  useEffect(() => {
    (async () => {
      try {
        if (view.name === "topics" && !topics) await loadTopics();
        if (view.name === "paths" && !paths) await loadPaths();
        if (view.name === "topic" && topicItems[view.slug] === undefined) await loadTopic(view.slug);
        if (view.name === "path" && pathSteps[view.slug] === undefined) await loadPath(view.slug);
        if (view.name === "item" && itemDetail[view.slug] === undefined) await loadItem(view.slug);
      } catch {
        // allow retry UI
      }
    })();
  }, [view, topics, paths, topicItems, pathSteps, itemDetail, loadTopics, loadPaths, loadTopic, loadPath, loadItem]);


  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      if (view.name === "home") {
        await loadTopics();
        await loadPaths();
      } else if (view.name === "topics") {
        await loadTopics();
      } else if (view.name === "paths") {
        await loadPaths();
      } else if (view.name === "topic") {
        await loadTopic(view.slug);
      } else if (view.name === "path") {
        await loadPath(view.slug);
      } else if (view.name === "item") {
        await loadItem(view.slug);
        // If the lesson is being displayed via WebView, also reload the page.
        webViewRef.current?.reload();
      }
    } finally {
      setRefreshing(false);
    }
  }, [view, loadTopics, loadPaths, loadTopic, loadPath, loadItem]);

  const headerTitle =
    view.name === "home"
      ? "Clinic"
      : view.name === "topics"
      ? "Topics"
      : view.name === "paths"
      ? "Training Paths"
      : view.name === "filters"
      ? "Filters"
      : view.name === "topic"
      ? view.title ?? "Topic"
      : view.name === "path"
      ? view.title ?? "Path"
      : view.title ?? "Lesson";

  const header = (
    <View style={[styles.header, { paddingTop: insets.top + 10 }]}>
      {stack.length > 1 ? (
        <View style={styles.headerRow}>
          <Pressable onPress={pop} style={({ pressed }) => [styles.headerBtn, pressed && styles.btnPressed]}>
            <Ionicons name="chevron-back" size={18} color={stylesVars.text} />
            <Text style={styles.headerBtnText}>Back</Text>
          </Pressable>

          <Text style={[styles.h1, { flex: 1, textAlign: "left", marginLeft: 6 }]}>{headerTitle}</Text>

          <Pressable onPress={goHome} style={({ pressed }) => [styles.headerIconBtn, pressed && styles.btnPressed]}>
            <Ionicons name="home-outline" size={18} color={stylesVars.text} />
          </Pressable>
        </View>
      ) : (
        <View style={styles.headerRow}>
          <Text style={[styles.h1, { flex: 1, textAlign: "left" }]}>{headerTitle}</Text>
        </View>
      )}

    </View>
  );

  if (view.name === "home") {
    const topTopics = (topics ?? []).slice(0, 6);
    const topPaths = (paths ?? []).slice(0, 4);

    return (
      <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
        {header}
        <ScrollView
          contentContainerStyle={styles.scroll}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={stylesVars.text} />}
        >
          <Pressable onPress={() => push({ name: "topics" })} style={({ pressed }) => [styles.bigCard, pressed && styles.cardPressed]}>
            <View style={styles.bigCardRow}>
              <View style={styles.bigIcon}>
                <Ionicons name="search-outline" size={18} color={stylesVars.text} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.bigTitle}>Find a skill</Text>
                <Text style={styles.bigSub}>Browse by topic: serve, return, dinking, drops, strategy…</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={stylesVars.textDim} style={{ opacity: 0.9 }} />
            </View>
          </Pressable>

          <Pressable onPress={() => push({ name: "paths" })} style={({ pressed }) => [styles.bigCard, pressed && styles.cardPressed]}>
            <View style={styles.bigCardRow}>
              <View style={styles.bigIcon}>
                <Ionicons name="map-outline" size={18} color={stylesVars.text} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.bigTitle}>Training paths</Text>
                <Text style={styles.bigSub}>Step-by-step programs that build skills in order.</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={stylesVars.textDim} style={{ opacity: 0.9 }} />
            </View>
          </Pressable>

          <View style={styles.sectionHead}>
            <Text style={styles.sectionTitle}>Popular topics</Text>
            <Pressable onPress={() => push({ name: "topics" })} style={({ pressed }) => [styles.linkBtn, pressed && styles.btnPressed]}>
              <Text style={styles.linkText}>View all</Text>
              <Ionicons name="chevron-forward" size={16} color={stylesVars.text} />
            </Pressable>
          </View>

          {loading && !topics ? (
            <View style={styles.box}>
              <ActivityIndicator color={stylesVars.text} />
              <Text style={styles.muted}>Loading topics…</Text>
            </View>
          ) : topTopics.length ? (
            <View style={styles.grid}>
              {topTopics.map((t) => (
                <SmallThumb
                  key={t.id}
                  title={t.name}
                  subtitle={compact(t.description) ?? "Guides, lessons, and drills organized to improve this skill."}
                  imageUrl={compact(t.featured_image_url)}
                  onPress={() => push({ name: "topic", slug: t.slug, title: t.name })}
                />
              ))}
            </View>
          ) : (
            <View style={styles.box}>
              <Text style={styles.muted}>No topics yet.</Text>
              <Pressable onPress={loadTopics} style={({ pressed }) => [styles.primaryBtn, pressed && styles.btnPressed]}>
                <Text style={styles.primaryBtnText}>Retry</Text>
              </Pressable>
            </View>
          )}

          <View style={styles.sectionHead}>
            <Text style={styles.sectionTitle}>Featured paths</Text>
            <Pressable onPress={() => push({ name: "paths" })} style={({ pressed }) => [styles.linkBtn, pressed && styles.btnPressed]}>
              <Text style={styles.linkText}>View all</Text>
              <Ionicons name="chevron-forward" size={16} color={stylesVars.text} />
            </Pressable>
          </View>

          {loading && !paths ? (
            <View style={styles.box}>
              <ActivityIndicator color={stylesVars.text} />
              <Text style={styles.muted}>Loading paths…</Text>
            </View>
          ) : topPaths.length ? (
            <View style={{ gap: 10 }}>
              {topPaths.map((p) => (
                <Row
                  key={p.id}
                  title={p.name}
                  subtitle={compact(p.description)}
                  meta={[
                    compact(p.intended_level)
                      ? LEVEL_LABEL[(p.intended_level ?? "").toLowerCase()] ?? p.intended_level
                      : null,
                    typeof p.est_total_minutes === "number" ? `${p.est_total_minutes} min` : null,
                    typeof p.step_count === "number" ? `${p.step_count} steps` : null,
                  ]
                    .filter(Boolean)
                    .join(" • ")}
                  imageUrl={compact(p.featured_image_url)}
                  onPress={() => push({ name: "path", slug: p.slug, title: p.name })}
                />
              ))}
            </View>
          ) : (
            <View style={styles.box}>
              <Text style={styles.muted}>No paths yet.</Text>
              <Pressable onPress={loadPaths} style={({ pressed }) => [styles.primaryBtn, pressed && styles.btnPressed]}>
                <Text style={styles.primaryBtnText}>Retry</Text>
              </Pressable>
            </View>
          )}

          <View style={{ height: insets.bottom + 24 }} />
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (view.name === "topics") {
    return (
      <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
        {header}
        <FlatList
          data={topics ?? []}
          keyExtractor={(t) => String(t.id)}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={stylesVars.text} />}
          ListEmptyComponent={
            <View style={styles.box}>
              {loading ? <ActivityIndicator color={stylesVars.text} /> : null}
              <Text style={styles.muted}>{loading ? "Loading topics…" : "No topics found."}</Text>
              {!loading ? (
                <Pressable onPress={loadTopics} style={({ pressed }) => [styles.primaryBtn, pressed && styles.btnPressed]}>
                  <Text style={styles.primaryBtnText}>Retry</Text>
                </Pressable>
              ) : null}
            </View>
          }
          renderItem={({ item }) => (
            <Row
              title={item.name}
              subtitle={compact(item.description)}
              imageUrl={compact(item.featured_image_url)}
              onPress={() => push({ name: "topic", slug: item.slug, title: item.name })}
            />
          )}
        />
      </SafeAreaView>
    );
  }

  if (view.name === "paths") {
    return (
      <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
        {header}
        <FlatList
          data={paths ?? []}
          keyExtractor={(p) => String(p.id)}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={stylesVars.text} />}
          ListEmptyComponent={
            <View style={styles.box}>
              {loading ? <ActivityIndicator color={stylesVars.text} /> : null}
              <Text style={styles.muted}>{loading ? "Loading paths…" : "No paths found."}</Text>
              {!loading ? (
                <Pressable onPress={loadPaths} style={({ pressed }) => [styles.primaryBtn, pressed && styles.btnPressed]}>
                  <Text style={styles.primaryBtnText}>Retry</Text>
                </Pressable>
              ) : null}
            </View>
          }
          renderItem={({ item }) => (
            <Row
              title={item.name}
              subtitle={compact(item.description)}
              meta={[
                compact(item.intended_level)
                  ? LEVEL_LABEL[(item.intended_level ?? "").toLowerCase()] ?? item.intended_level
                  : null,
                typeof item.est_total_minutes === "number" ? `${item.est_total_minutes} min` : null,
                typeof item.step_count === "number" ? `${item.step_count} steps` : null,
              ]
                .filter(Boolean)
                .join(" • ")}
              imageUrl={compact(item.featured_image_url)}
              onPress={() => push({ name: "path", slug: item.slug, title: item.name })}
            />
          )}
        />
      </SafeAreaView>
    );
  }


  if (view.name === "filters") {
    const slug = view.slug;

    const typeOptions: { value: string; label: string }[] = [
      { value: "", label: "Any type" },
      { value: "guide", label: "Guide" },
      { value: "lesson", label: "Lesson" },
      { value: "drill", label: "Drill" },
      { value: "troubleshoot", label: "Troubleshoot" },
    ];

    const levelOptions: { value: string; label: string }[] = [
      { value: "", label: "Any level" },
      { value: "beginner", label: "Beginner" },
      { value: "intermediate", label: "Intermediate" },
      { value: "advanced", label: "Advanced" },
      { value: "all", label: "All levels" },
    ];

    const done = () => {
      pop();
      loadTopic(slug);
    };

    return (
      <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
        {header}

        <ScrollView
          contentContainerStyle={styles.scroll}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={stylesVars.text} />}
        >
          <View style={styles.filterSection}>
            <Text style={styles.filterSectionTitle}>Type</Text>
            {typeOptions.map((opt) => (
              <Pressable
                key={opt.value || "__any"}
                onPress={() => setType(opt.value)}
                style={({ pressed }) => [styles.filterRow, pressed && styles.rowPressed]}
              >
                <Text style={styles.filterRowText}>{opt.label}</Text>
                {type === opt.value ? <Ionicons name="checkmark" size={18} color={stylesVars.accent} /> : null}
              </Pressable>
            ))}
          </View>

          <View style={styles.filterSection}>
            <Text style={styles.filterSectionTitle}>Level</Text>
            {levelOptions.map((opt) => (
              <Pressable
                key={opt.value || "__any"}
                onPress={() => setLevel(opt.value)}
                style={({ pressed }) => [styles.filterRow, pressed && styles.rowPressed]}
              >
                <Text style={styles.filterRowText}>{opt.label}</Text>
                {level === opt.value ? <Ionicons name="checkmark" size={18} color={stylesVars.accent} /> : null}
              </Pressable>
            ))}
          </View>

          <View style={{ flexDirection: "row", gap: 10 }}>
            <Pressable
              onPress={() => {
                setType("");
                setLevel("");
              }}
              style={({ pressed }) => [styles.secondaryBtn, pressed && styles.btnPressed, { flex: 1 }]}
            >
              <Text style={styles.secondaryBtnText}>Clear</Text>
            </Pressable>

            <Pressable onPress={done} style={({ pressed }) => [styles.primaryBtn, pressed && styles.btnPressed, { flex: 1 }]}>
              <Text style={styles.primaryBtnText}>Done</Text>
            </Pressable>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }


  if (view.name === "topic") {
    const items = topicItems[view.slug];

    return (
      <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
        {header}


        <View style={styles.filters}>
          <TextInput
            value={q}
            onChangeText={setQ}
            placeholder="Search this topic…"
            placeholderTextColor={stylesVars.textFaint}
            style={styles.search}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="search"
            onSubmitEditing={() => loadTopic(view.slug)}
          />

          <Pressable
            onPress={() => push({ name: "filters", slug: view.slug, title: "Filters" })}
            style={({ pressed }) => [styles.filterIconBtn, pressed && styles.btnPressed]}
          >
            <Ionicons name="options-outline" size={18} color={stylesVars.text} />
          </Pressable>
        </View>

        <FlatList
          data={items ?? []}
          keyExtractor={(it) => String(it.id)}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={stylesVars.text} />}
          ListEmptyComponent={
            <View style={styles.box}>
              {loading ? <ActivityIndicator color={stylesVars.text} /> : null}
              <Text style={styles.muted}>
                {loading ? "Loading lessons…" : items === undefined ? "Loading lessons…" : "No items found."}
              </Text>
              {!loading ? (
                <Pressable onPress={() => loadTopic(view.slug)} style={({ pressed }) => [styles.primaryBtn, pressed && styles.btnPressed]}>
                  <Text style={styles.primaryBtnText}>{items === undefined ? "Retry" : "Refresh"}</Text>
                </Pressable>
              ) : null}
            </View>
          }
          renderItem={({ item }) => (
            <Row
              title={item.title}
              subtitle={compact(item.excerpt)}
              meta={pillText(item)}
              imageUrl={compact(item.featured_image_url)}
              onPress={() => push({ name: "item", slug: item.slug, title: item.title })}
            />
          )}
        />
      </SafeAreaView>
    );
  }

  if (view.name === "path") {
    const steps = pathSteps[view.slug];

    return (
      <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
        {header}
        <FlatList
          data={steps ?? []}
          keyExtractor={(s) => String(s.step_no)}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={stylesVars.text} />}
          ListEmptyComponent={
            <View style={styles.box}>
              {loading ? <ActivityIndicator color={stylesVars.text} /> : null}
              <Text style={styles.muted}>{loading ? "Loading steps…" : steps === undefined ? "Loading steps…" : "No steps."}</Text>
              {!loading ? (
                <Pressable onPress={() => loadPath(view.slug)} style={({ pressed }) => [styles.primaryBtn, pressed && styles.btnPressed]}>
                  <Text style={styles.primaryBtnText}>{steps === undefined ? "Retry" : "Refresh"}</Text>
                </Pressable>
              ) : null}
            </View>
          }
          renderItem={({ item }) => (
            <Row
              title={`${item.step_no}. ${item.step_title}`}
              subtitle={compact(item.note) ?? compact(item.item.excerpt)}
              meta={pillText(item.item)}
              imageUrl={compact(item.item.featured_image_url)}
              onPress={() => push({ name: "item", slug: item.item.slug, title: item.step_title })}
            />
          )}
        />
      </SafeAreaView>
    );
  }

  if (view.name === "item") {
    const item = itemDetail[view.slug];
    const websiteItemUrl = `https://whatyoudink.com/clinic/item.php?slug=${encodeURIComponent(view.slug)}&app=1`;

    const WEBVIEW_HEIGHT_JS = `
      (function () {
        function postHeight() {
          var height = Math.max(
            document.body ? document.body.scrollHeight : 0,
            document.documentElement ? document.documentElement.scrollHeight : 0
          );
          window.ReactNativeWebView && window.ReactNativeWebView.postMessage(String(height));
        }
        setTimeout(postHeight, 50);
        setTimeout(postHeight, 250);
        setTimeout(postHeight, 750);
        window.addEventListener('load', postHeight);
      })();
      true;
    `;

    return (
      <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
        {header}

        <ScrollView contentContainerStyle={styles.scroll} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={stylesVars.text} />}>
          {!item ? (
            <View style={styles.box}>
              {loading ? <ActivityIndicator color={stylesVars.text} /> : null}
              <Text style={styles.muted}>{loading ? "Loading…" : "Loading…"}</Text>
              {!loading ? (
                <Pressable onPress={() => loadItem(view.slug)} style={({ pressed }) => [styles.primaryBtn, pressed && styles.btnPressed]}>
                  <Text style={styles.primaryBtnText}>Retry</Text>
                </Pressable>
              ) : null}
            </View>
          ) : compact(item.content_html) ? (
            <View style={{ flex: 1 }}>
              <WebView
                ref={webViewRef}
                source={{ uri: websiteItemUrl }}
                originWhitelist={["*"]}
                injectedJavaScript={WEBVIEW_HEIGHT_JS}
                onMessage={(e) => {
                  const h = parseInt(String(e.nativeEvent.data || ""), 10);
                  if (!Number.isFinite(h)) return;
                  if (h < 200) return;
                  // Prevent runaway sizes if a page misbehaves.
                  setWebViewHeight(Math.min(h, 20000));
                }}
                // Let the native ScrollView handle scroll + pull-to-refresh.
                scrollEnabled={false}
                style={{ width: "100%", height: webViewHeight, backgroundColor: "transparent" }}
                startInLoadingState
                renderLoading={() => (
                  <View style={styles.box}>
                    <ActivityIndicator color={stylesVars.text} />
                    <Text style={styles.muted}>Loading…</Text>
                  </View>
                )}
              />
            </View>
          ) : (
            <View style={{ gap: 12 }}>
              {compact(item.featured_image_url) ? <Image source={{ uri: item.featured_image_url! }} style={styles.heroImg} /> : null}

              <View>
                <Text style={styles.itemTitle}>{item.title}</Text>
                {pillText(item) ? <Text style={styles.itemMeta}>{pillText(item)}</Text> : null}
              </View>

              {compact(item.excerpt) ? <Text style={styles.itemExcerpt}>{item.excerpt}</Text> : null}

              {compact(item.youtube_url) ? (
                <Pressable onPress={() => Linking.openURL(item.youtube_url!)} style={({ pressed }) => [styles.primaryBtn, pressed && styles.btnPressed]}>
                  <Ionicons name="logo-youtube" size={18} color={stylesVars.accentInk} />
                  <Text style={[styles.primaryBtnText, { marginLeft: 8 }]}>Watch on YouTube</Text>
                </Pressable>
              ) : null}
            </View>
          )}

          <View style={{ height: insets.bottom + 24 }} />
        </ScrollView>
      </SafeAreaView>
    );
  }

  return null;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: stylesVars.bg },

  header: { paddingHorizontal: 14, paddingBottom: 10 },
  headerRow: {
    justifyContent: "flex-start", flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  h1: { fontSize: 28, fontWeight: "900", color: stylesVars.text, letterSpacing: -0.3 },
  sub: { marginTop: 6, color: stylesVars.textDim, fontSize: 13, lineHeight: 18 },

  headerBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 12,
    backgroundColor: stylesVars.card,
    borderWidth: 1,
    borderColor: stylesVars.cardBorder,
  },
  headerIconBtn: {
    width: 44,
    height: 36,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: stylesVars.card,
    borderWidth: 1,
    borderColor: stylesVars.cardBorder,
  },
  headerBtnText: { fontWeight: "800", color: stylesVars.text },
  btnPressed: { opacity: 0.85 },

  scroll: { paddingHorizontal: 14, paddingBottom: 10 },
  list: { paddingHorizontal: 14, paddingBottom: 20 },

  bigCard: {
    borderRadius: 18,
    padding: 14,
    backgroundColor: stylesVars.card,
    borderWidth: 1,
    borderColor: stylesVars.cardBorder,
    marginTop: 10,
  },
  cardPressed: { backgroundColor: "rgba(255,255,255,0.09)" },
  bigCardRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  bigIcon: {
    width: 34,
    height: 34,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(199,255,46,0.12)",
  },
  bigTitle: { fontSize: 15, fontWeight: "900", color: stylesVars.text },
  bigSub: { marginTop: 3, color: stylesVars.textDim, fontSize: 13, lineHeight: 17 },

  sectionHead: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 14, marginBottom: 8 },
  sectionTitle: { fontSize: 14, fontWeight: "900", opacity: 0.95, color: stylesVars.text },
  linkBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: stylesVars.card,
    borderWidth: 1,
    borderColor: stylesVars.cardBorder,
  },
  linkText: { fontWeight: "900", color: stylesVars.text },

  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  thumb: { width: "48%", borderRadius: 18, overflow: "hidden", backgroundColor: stylesVars.card, borderWidth: 1, borderColor: stylesVars.cardBorder },
  thumbImgWrap: { width: "100%", aspectRatio: 16 / 10, backgroundColor: "rgba(255,255,255,0.04)" },
  thumbImg: { width: "100%", height: "100%" },
  thumbImgFallback: { flex: 1, backgroundColor: "rgba(255,255,255,0.04)" },
  thumbBody: { padding: 10 },
  thumbTitle: { fontWeight: "900", fontSize: 13, color: stylesVars.text },
  thumbSub: { marginTop: 4, color: stylesVars.textDim, fontSize: 12, lineHeight: 16 },

  row: { flexDirection: "row", alignItems: "center", gap: 12, padding: 12, borderRadius: 18, backgroundColor: stylesVars.card, borderWidth: 1, borderColor: stylesVars.cardBorder, marginBottom: 10 },
  rowPressed: { backgroundColor: "rgba(255,255,255,0.09)" },
  rowImgWrap: { width: 56, height: 56, borderRadius: 14, overflow: "hidden", backgroundColor: "rgba(255,255,255,0.04)" },
  rowImg: { width: "100%", height: "100%" },
  rowImgFallback: { flex: 1, backgroundColor: "rgba(255,255,255,0.04)" },
  rowTitle: { fontSize: 14, fontWeight: "900", color: stylesVars.text },
  rowSub: { marginTop: 3, color: stylesVars.textDim, fontSize: 12, lineHeight: 16 },
  rowMeta: { marginTop: 5, color: stylesVars.textFaint, fontSize: 12, fontWeight: "800" },

  filters: { paddingHorizontal: 14, paddingBottom: 10, flexDirection: "row", gap: 8, alignItems: "center" },
  search: {
    flex: 1,
    height: 40,
    borderRadius: 14,
    paddingHorizontal: 12,
    backgroundColor: stylesVars.card,
    borderWidth: 1,
    borderColor: stylesVars.cardBorder,
    color: stylesVars.text,
  },
  pill: { height: 40, paddingHorizontal: 10, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: stylesVars.card, borderWidth: 1, borderColor: stylesVars.cardBorder },
  pillText: { fontWeight: "900", fontSize: 12, color: stylesVars.text },
  pillGo: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: stylesVars.accent },


  filterIconBtn: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: stylesVars.card, borderWidth: 1, borderColor: stylesVars.cardBorder },

  filterSection: { padding: 14, borderRadius: 18, backgroundColor: stylesVars.card, borderWidth: 1, borderColor: stylesVars.cardBorder, marginBottom: 12 },
  filterSectionTitle: { fontSize: 14, fontWeight: "900", color: stylesVars.text, marginBottom: 10 },
  filterRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 12, paddingHorizontal: 12, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.03)", borderWidth: 1, borderColor: "rgba(255,255,255,0.06)", marginBottom: 10 },
  filterRowText: { fontSize: 13, fontWeight: "800", color: stylesVars.text },

  secondaryBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical: 12, paddingHorizontal: 14, borderRadius: 16, backgroundColor: stylesVars.card, borderWidth: 1, borderColor: stylesVars.cardBorder },
  secondaryBtnText: { fontWeight: "900", color: stylesVars.text },

  primaryBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical: 12, paddingHorizontal: 14, borderRadius: 16, backgroundColor: stylesVars.accent },
  primaryBtnText: { fontWeight: "900", color: stylesVars.accentInk },

  box: { marginTop: 12, padding: 14, borderRadius: 18, backgroundColor: stylesVars.card, borderWidth: 1, borderColor: stylesVars.cardBorder, alignItems: "center", gap: 10 },
  muted: { color: stylesVars.textDim, fontWeight: "700" },

  heroImg: { width: "100%", aspectRatio: 16 / 10, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.04)" },
  itemTitle: { fontSize: 20, fontWeight: "900", color: stylesVars.text },
  itemMeta: { marginTop: 6, color: stylesVars.textDim, fontWeight: "900" },
  itemExcerpt: { color: stylesVars.textDim, lineHeight: 20 },

  htmlBox: { padding: 14, borderRadius: 18, backgroundColor: stylesVars.card, borderWidth: 1, borderColor: stylesVars.cardBorder },
  htmlHint: { color: stylesVars.textDim, lineHeight: 18, fontWeight: "700" },
});
