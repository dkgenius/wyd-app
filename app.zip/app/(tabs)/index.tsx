// app/(tabs)/index.tsx
import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Image,
  RefreshControl,
  Linking,
} from "react-native";
import * as Location from "expo-location";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

const API_BASE = "https://whatyoudink.com";

type ApiNearbyLocation = {
  id: number;
  name: string;
  city: string;
  state: string;
  distance_mi?: number | null;
  rating_overall?: number | null;
  blog?: {
    id: number | null;
    slug?: string | null;
    title?: string | null;
    url?: string | null;
  };
};

type ApiPost = {
  id: number;
  slug: string;
  title: string;
  excerpt?: string | null;
  featured_image_url?: string | null;
  published_at?: string | null;
  location?: {
    id?: number | null;
    name?: string | null;
    city?: string | null;
    state?: string | null;
    rating_overall?: number | null;
  };
};

function slugFromBlogUrl(url?: string | null): string | null {
  if (!url) return null;
  const m = url.match(/\/blog\/([^/?#]+)/i);
  return m ? m[1] : null;
}

function fmtRating(r?: number | null) {
  if (typeof r !== "number" || Number.isNaN(r)) return null;
  return r.toFixed(1);
}

function Logo() {
  return (
    <View style={styles.logoWrap}>
      <Image source={require("../../assets/images/whatyoudinklogo-outline.png")} style={styles.logo} />

      <View style={styles.socials}>
        <Pressable
          onPress={() => Linking.openURL("https://www.instagram.com/whatyoudink")}
          style={({ pressed }) => [styles.socialIcon, pressed && styles.pressedIcon]}
          accessibilityRole="link"
          accessibilityLabel="Instagram"
        >
          <Ionicons name="logo-instagram" size={22} color="rgba(255,255,255,0.92)" />
        </Pressable>

        <Pressable
          onPress={() => Linking.openURL("https://www.youtube.com/@whatyoudink")}
          style={({ pressed }) => [styles.socialIcon, pressed && styles.pressedIcon]}
          accessibilityRole="link"
          accessibilityLabel="YouTube"
        >
          <Ionicons name="logo-youtube" size={24} color="rgba(255,255,255,0.92)" />
        </Pressable>

        <Pressable
          onPress={() => Linking.openURL("https://www.tiktok.com/@whatyoudink")}
          style={({ pressed }) => [styles.socialIcon, pressed && styles.pressedIcon]}
          accessibilityRole="link"
          accessibilityLabel="TikTok"
        >
          <Ionicons name="logo-tiktok" size={22} color="rgba(255,255,255,0.92)" />
        </Pressable>
      </View>
    </View>
  );
}




function QuickAction({
  label,
  icon,
  onPress,
}: {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.qa, pressed && styles.pressed]}>
      <View style={styles.qaIcon}>
        <Ionicons name={icon} size={22} color="rgba(255,255,255,0.92)" />
      </View>
      <Text style={styles.qaLabel}>{label}</Text>
    </Pressable>
  );
}

export default function HomeScreen() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [nearby, setNearby] = useState<ApiNearbyLocation[]>([]);
  const [postsBySlug, setPostsBySlug] = useState<Record<string, ApiPost>>({});
  const [error, setError] = useState<string | null>(null);

  const reviewedNearby = useMemo(
    () => nearby.filter((x) => !!(x.blog?.slug || x.blog?.url)),
    [nearby]
  );

  const openBlogInApp = (loc: ApiNearbyLocation) => {
    const slug = loc.blog?.slug || slugFromBlogUrl(loc.blog?.url);
    if (!slug) return;
    router.push({ pathname: "/blog/[slug]", params: { slug } });
  };

  async function load() {
    try {
      setError(null);
      setLoading(true);

      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setError("Location permission not granted.");
        setNearby([]);
        setPostsBySlug({});
        setLoading(false);
        return;
      }

      const loc = await Location.getCurrentPositionAsync({});
      const lat = loc.coords.latitude;
      const lng = loc.coords.longitude;

      // 1) Fetch nearby locations (includes blog slug/title + rating_overall)
      const nearbyUrl =
        `${API_BASE}/api/v1/locations/nearby.php` +
        `?lat=${encodeURIComponent(lat)}` +
        `&lng=${encodeURIComponent(lng)}` +
        `&radius=10`;

      const res = await fetch(nearbyUrl);
      const json = await res.json();

      if (!json?.ok) {
        setError(json?.error || "API error");
        setNearby([]);
        setPostsBySlug({});
        setLoading(false);
        return;
      }

      const locs: ApiNearbyLocation[] = json.locations || [];
      setNearby(locs);

      // 2) Fetch recent posts so we can show featured images for nearby review cards
      // (We map slug -> featured_image_url, title, etc.)
      const postsRes = await fetch(`${API_BASE}/api/v1/posts.php?limit=100`);
      const postsJson = await postsRes.json();

      if (postsJson?.ok && Array.isArray(postsJson.posts)) {
        const map: Record<string, ApiPost> = {};
        for (const p of postsJson.posts as ApiPost[]) {
          if (p?.slug) map[p.slug] = p;
        }
        setPostsBySlug(map);
      } else {
        setPostsBySlug({});
      }

      setLoading(false);
    } catch (e: any) {
      setError(e?.message || "Failed to load");
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      await load();
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        keyboardShouldPersistTaps="handled"
      >
        <Logo />

        <View style={styles.qaRow}>
          <QuickAction label="Map" icon="map-outline" onPress={() => router.push("/map")} />
          <QuickAction label="Clinic" icon="fitness-outline" onPress={() => router.push("/clinic")} />
          <QuickAction label="Articles" icon="newspaper-outline" onPress={() => router.push("/blog")} />
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHead}>
            <Text style={styles.sectionTitle}>Nearby Reviews</Text>
          </View>

          {loading ? (
            <View style={{ paddingVertical: 18, alignItems: "center" }}>
              <ActivityIndicator />
              <Text style={[styles.muted, { marginTop: 10 }]}>Loading…</Text>
            </View>
          ) : error ? (
            <Text style={[styles.muted, { marginTop: 8 }]}>{error}</Text>
          ) : reviewedNearby.length === 0 ? (
            <Text style={[styles.muted, { marginTop: 8 }]}>No reviewed courts found nearby.</Text>
          ) : (
            reviewedNearby.slice(0, 8).map((loc) => {
              const slug = loc.blog?.slug || slugFromBlogUrl(loc.blog?.url);
              const post = slug ? postsBySlug[slug] : undefined;
              const imageUrl = post?.featured_image_url || null;
              const rating = fmtRating(loc.rating_overall);

              return (
                <Pressable key={loc.id} style={({ pressed }) => [styles.reviewCard, pressed && styles.pressed]} onPress={() => openBlogInApp(loc)}>
                  <View style={styles.reviewImageWrap}>
                    {imageUrl ? (
                      <Image source={{ uri: imageUrl }} style={styles.reviewImage} />
                    ) : (
                      <View style={styles.reviewImageFallback} />
                    )}

                    {rating ? (
                      <View style={styles.ratingPill}>
                        <Ionicons name="star" size={14} color="#0b0f14" />
                        <Text style={styles.ratingText}>{rating}</Text>
                      </View>
                    ) : null}
                  </View>

                  <View style={styles.reviewBody}>
                    <Text style={styles.reviewTitle} numberOfLines={2}>
                      {loc.blog?.title || post?.title || loc.name}
                    </Text>
                    <Text style={styles.reviewMeta} numberOfLines={1}>
                      {loc.name} • {loc.city}, {loc.state}
                    </Text>
                  </View>
                </Pressable>
              );
            })
          )}
        </View>

        <View style={{ height: 16 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#0b0f14" },
  container: { flex: 1, backgroundColor: "#0b0f14" },
  content: { padding: 16, paddingBottom: 24 },

  logoWrap: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: 6,
    paddingBottom: 10,
  },
  logo: { width: 64, height: 64, borderRadius: 16 },

  socials: { flexDirection: "row", alignItems: "center" },
  socialIcon: { marginLeft: 14, padding: 6 },
  pressedIcon: { opacity: 0.7 },

  qaRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 10,
    marginTop: 8,
    marginBottom: 10,
  },
  qa: {
    flex: 1,
    borderRadius: 18,
    paddingVertical: 12,
    paddingHorizontal: 10,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
  },
  qaIcon: {
    width: 42,
    height: 42,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(199,255,46,0.10)",
    marginBottom: 8,
  },
  qaLabel: { color: "rgba(255,255,255,0.92)", fontWeight: "900" },

  pressed: { opacity: 0.88 },

  section: { marginTop: 6 },
  sectionHead: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  sectionTitle: { fontSize: 16, fontWeight: "900", color: "rgba(255,255,255,0.92)" },
  muted: { color: "rgba(255,255,255,0.55)", fontWeight: "700" },

  reviewCard: {
    marginTop: 12,
    borderRadius: 18,
    overflow: "hidden",
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
  },
  reviewImageWrap: { width: "100%", aspectRatio: 16 / 9, backgroundColor: "rgba(255,255,255,0.04)" },
  reviewImage: { width: "100%", height: "100%" },
  reviewImageFallback: { flex: 1, backgroundColor: "rgba(255,255,255,0.05)" },

  ratingPill: {
    position: "absolute",
    top: 10,
    left: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: "#c7ff2e",
  },
  ratingText: { fontWeight: "900", color: "#0b0f14" },

  reviewBody: { padding: 12 },
  reviewTitle: { color: "rgba(255,255,255,0.92)", fontSize: 14, fontWeight: "900" },
  reviewMeta: { marginTop: 6, color: "rgba(255,255,255,0.65)", fontWeight: "800", fontSize: 12 },
});
